import React from "react";
import { useState, useEffect } from "react";
import { Container,Stack, Row, Col, Form, Table } from "react-bootstrap";
import axios from "axios";
//import { useSnackbar } from "notistack";
import Button from "@mui/material/Button";
import EditUserOnly from "./EditUserOnly";
import Search from "./Search";
import CustomPagination from "./CustomPagination";
//import { FormControlUnstyledContext } from "@mui/base";

const tableData=()=> {
  const [users, set_Users] = useState([]);
  //const { enqueueSnackbar } = useSnackbar();
  const [users_filtered, set_Users_Filtered] = useState([]);
  const [show_edit, set_Show_Edit] = useState(false);
  const [find_user, set_Find_User] = useState("");
  const [all_checked, set_All_Checked] = useState(false);
  const [user_update, set_User_Update] = useState(null);
  const [users_selected, set_Users_Selected] = useState([]);
  const [current_page, set_Current_Page] = useState(1);
  const page = 10;


  const URL =
    "https://geektrust.s3-ap-southeast-1.amazonaws.com/adminui-problem/members.json";


  const update_user = (userId) => {
    set_User_Update(userId);
    set_Show_Edit(true);
  };

  const data = async () => {
    try {
      const res = await axios.get(URL);
      set_Users(res.data);
    } catch (err) {
      console.log("Fetching users data failed", err);
    }
  };

  const handle_delete_all = () => {
    const new_list = users.filter(
      (user) => !users_selected.includes(user.id)
    );

    const new_filtered_list = users_filtered.filter(
      (user) => !users_selected.includes(user.id)
    );

    set_Users(new_list);
    set_Users_Filtered(new_filtered_list);
    set_All_Checked(false);

    if (users_selected.length) {
      console.log("Data deleted successfully ")
    } else {
      console.log("No data selected to delete ")
    }
  };

  const handle_select_all = (event) => {
    let new_list = [...users_selected];
    if (event.target.checked) {
      set_All_Checked(true);
      new_list = current_Users.map((user) => user.id);
    } else {
      set_All_Checked(false);
      new_list = [];
    }
    set_Users_Selected(new_list);
  };

  const handle_select = (event) => {
    let new_list = [...users_selected];
    const userId = event.target.value;

    if (event.target.checked) {
      new_list = [...users_selected, userId];
    } else {
      set_All_Checked(false);
      new_list.splice(users_selected.indexOf(userId), 1);
    }
    set_Users_Selected(new_list);
  };

  const handle_delete = (userId) => {
    const new_list = users.filter((user) => user.id !== userId);
    console.log("Data deleted successfully")
    set_Users(new_list);
  };

  const search = (event) => {
    set_Find_User(event.target.value);
  };

  const filter = () => {
    if (find_user === "") {
      
      set_Users_Filtered(users);
    } else {
      
      const result = users.filter((obj) =>
        Object.keys(obj).some((key) => obj[key].includes(find_user))
      );
      set_Users_Filtered(result);
    }
  };

  useEffect(() => {
    data();
  }, []);

  useEffect(() => {
    filter();
  }, [users, find_user]);

  const paginate = (pageNumber) => {
    if (!all_checked) {
      set_All_Checked(false);
    }
    set_Current_Page(pageNumber);
  };

  const index_last_user = current_page * page;
  const index_first_user = index_last_user - page;
  const current_Users = users_filtered.length
    ? users_filtered.slice(index_first_user, index_last_user)
    : users.slice(index_first_user, index_last_user);
  const total_Users = users_filtered.length;
  const total_Page = Math.ceil(total_Users / page);


  return (
    <Container>
      <Row>
        <Col>
          <Search search={search} />
        </Col>
      </Row>
      <Row>
        <Col>
          <Table>
            <thead>
              <tr>
                <th>
                  <Form.Check
                    type="checkbox"
                    onChange={handle_select_all}
                    checked={all_checked}
                  />
                </th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {current_Users.map((user) => {
                return (
                  <tr key={user.id}>
                    <td>
                      <Form.Check
                        type="checkbox"
                        value={user.id}
                        checked={users_selected.includes(user.id)}
                        onChange={handle_select}
                      />
                    </td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>{user.role}</td>
                    <td>
                      <Stack direction="horizontal">
                        <Button
                          size="sm"
                          variant="link"
                          onClick={() => update_user(user.id)}
                        >
                          <i className="bi bi-pencil-fill text-primary"></i>
                        </Button>

                        <Button
                          size="sm"
                          variant="link"
                          onClick={() => handle_delete(user.id)}
                        >
                          <i className="bi bi-trash-fill text-danger"></i>
                        </Button>
                      </Stack>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </Col>
      </Row>
      {
        <Row className="pt-2 pt-md-0">
          <Col xs="12" md="4" sm="6">
            <Button
              variant="contained"
              onClick={handle_delete_all}
              color="secondary"
            >
              Delete the selected users
            </Button>
          </Col>
          <Col xs="12" md="8" sm="6">
            <CustomPagination
              current_page={current_page}
              checked={all_checked}
              paginate={paginate}
              total_Page={total_Page}
              disabled={users_selected.length > 0 ? false : true}
            />
          </Col>
        </Row>
      }
      {show_edit ? (
        <EditUserOnly
          users={users}
          userId={user_update}
          set_Users={set_Users}
          set_Show_Edit={set_Show_Edit}
          onHide={() => set_Show_Edit(false)}
          show={show_edit}
        />
      ) : null}
    </Container>
  );
}

export default tableData;