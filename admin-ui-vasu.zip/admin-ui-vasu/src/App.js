import React from "react";
import TableData from "./TableData";

function App() {
  return (
    <div className="App">
      <TableData/>
    </div>
  );
}

export default App;